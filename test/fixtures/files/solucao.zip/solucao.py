print('oi')
